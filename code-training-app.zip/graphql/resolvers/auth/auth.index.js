const Mutation = require('./auth.mutations')
const Query = require('./auth.queries')

module.exports = {
    Mutation,
    Query
}