const db = require('./../../../model/index')
const { regular } = require('./../../../utils/helpers/middleware')

const educatorRead = async(_, { _id }, { req }, info) => {
    regular(req)
    try {
        const _educator = await db.Educator.findOne({ where: { _id } })
        return _educator
    } catch (err) {
        throw err
    }
}

const educatorList = async(_, { filter, sorting, paging }, { }, info) => {
    regular(req)
    try {
        const _educators = await db.Educator.findAll()
        return _educators
    } catch (err) {
        
    }
}
module.exports = {
    educatorRead,
    educatorList
}