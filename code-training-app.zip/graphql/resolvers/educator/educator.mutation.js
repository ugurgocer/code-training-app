const db = require('./../../../model/index')
const { ValidationError } = require('./../../../utils/errors/index')
const { parseError } = require('./../../../utils/helpers/other')

const educatorCreate = async(_, { educator }, { req }, info) => {
    return db.sequelize.transaction(async trx => {
        try{
            const _educator = await db.Educator.create(educator, { transaction: trx })            
            return _educator
        }catch(err){
            const customErr = parseError(err)
            if(customErr){
                if(customErr.type === 'validate')
                    throw new ValidationError(customErr.errors)
            }else
                throw err

            throw errors
        }
    })
}

const educatorUpdate = async(_, { _id, educator }, { req }, info) => {
    return db.sequelize.transaction(async trx => {
        try {
            const _educator = await db.Educator.update(educator, _id , {transaction: trx})
            return _educator
        } catch (err) {
            const customErr = parseError(err)
            if(customErr){
                if(customErr.type === 'validate')
                    throw new ValidationError(customErr.errors)
            }else
                throw err

            throw errors
        }
    })
}

const educatorDelete = async(_, { _id }, { req }, info) => {
    return db.sequelize.transaction(async trx => {
        try {
            await db.Educator.destroy({ where: { _id }}, {transaction: trx})
        } catch (err) {
            const customErr = parseError(err)
            if(customErr){
                if(customErr.type === 'validate')
                    throw new ValidationError(customErr.errors)
                else if(customErr.type === 'foreignkey')
                    throw new ValidationError(customErr.errors)
            }else
                throw err

            throw errors
        }
    })
}

module.exports = {
    educatorCreate,
    educatorUpdate,
    educatorDelete
}