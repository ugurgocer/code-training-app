const Mutation = require('./educator.mutation')
const Query = require('./educator.query')

module.exports = {
    Mutation,
    Query
}