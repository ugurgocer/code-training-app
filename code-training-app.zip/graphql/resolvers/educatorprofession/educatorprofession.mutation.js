const db = require('./../../../model/index')
const { ValidationError } = require('./../../../utils/errors/index')
const { parseError } = require('./../../../utils/helpers/other')

const educatorProfessionCreate = async(_, { educatorProfession }, { req }, info) => {
    return db.sequelize.transaction(async trx => {
        try{
            const _educatorProfession = await db.EducatorProfession.create(educatorProfession, { transaction: trx })            
            return _educatorProfession
        }catch(err){
            const customErr = parseError(err)
            if(customErr){
                if(customErr.type === 'validate')
                    throw new ValidationError(customErr.errors)
            }else
                throw err

            throw errors
        }
    })
}

const educatorProfessionUpdate = async(_, { _id, educatorProfession }, { req }, info) => {
    return db.sequelize.transaction(async trx => {
        try {
            const _educatorProfession = await db.EducatorProfession.update(educatorProfession, _id , {transaction: trx})
            return _educatorProfession
        } catch (err) {
            const customErr = parseError(err)
            if(customErr){
                if(customErr.type === 'validate')
                    throw new ValidationError(customErr.errors)
            }else
                throw err

            throw errors
        }
    })
}

const educatorProfessionDelete = async(_, { _id }, { req }, info) => {
    return db.sequelize.transaction(async trx => {
        try {
            await db.EducatorProfession.destroy({ where: { _id }}, {transaction: trx})
        } catch (err) {
            const customErr = parseError(err)
            if(customErr){
                if(customErr.type === 'validate')
                    throw new ValidationError(customErr.errors)
            }else
                throw err

            throw errors
        }
    })
}

module.exports = {
    educatorProfessionCreate,
    educatorProfessionUpdate,
    educatorProfessionDelete
}