const db = require('./../../../model/index')
const { regular } = require('./../../../utils/helpers/middleware')

const educatorProfessionRead = async(_, { _id }, { req }, info) => {
    regular(req)
    try {
        const _educatorProfession = await db.EducatorProfession.findOne({ where: { _id } })
        return _educatorProfession
    } catch (err) {
        throw err
    }
}

const educatorProfessionList = async(_, { filter, sorting, paging }, { }, info) => {
    regular(req)
    try {
        const _educatorProfessions = await db.EducatorProfession.findAll()
        return _educatorProfessions
    } catch (err) {
        
    }
}
module.exports = {
    educatorProfessionRead,
    educatorProfessionList
}