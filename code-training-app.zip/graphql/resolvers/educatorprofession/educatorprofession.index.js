const Mutation = require('./educatorprofession.mutation')
const Query = require('./educatorprofession.query')

module.exports = {
    Mutation,
    Query
}