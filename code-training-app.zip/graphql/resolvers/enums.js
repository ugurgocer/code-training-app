module.exports = {
    LoginType: {
        EDUCATOR: 'educator',
        REGULAR: 'regular'
    }
}