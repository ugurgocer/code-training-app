const db = require('./../../../model/index')
const { ValidationError } = require('./../../../utils/errors/index')
const { parseError } = require('./../../../utils/helpers/other')

const courseCreate = async(_, { course }, { req }, info) => {
    return db.sequelize.transaction(async trx => {
        try{
            const _course = await db.Course.create(course, { transaction: trx })            
            return _course
        }catch(err){
            const customErr = parseError(err)
            if(customErr){
                if(customErr.type === 'validate')
                    throw new ValidationError(customErr.errors)
            }else
                throw err

            throw errors
        }
    })
}

const courseUpdate = async(_, { _id, course }, { req }, info) => {
    return db.sequelize.transaction(async trx => {
        try {
            const _course = await db.Course.update(course, _id , {transaction: trx})
            return _course
        } catch (err) {
            const customErr = parseError(err)
            if(customErr){
                if(customErr.type === 'validate')
                    throw new ValidationError(customErr.errors)
            }else
                throw err

            throw errors
        }
    })
}

const courseDelete = async(_, { _id }, { req }, info) => {
    return db.sequelize.transaction(async trx => {
        try {
            await db.Course.destroy({ where: { _id }}, {transaction: trx})
        } catch (err) {
            const customErr = parseError(err)
            if(customErr){
                if(customErr.type === 'validate')
                    throw new ValidationError(customErr.errors)
                else if(customErr.type === 'foreignkey')
                    throw new ValidationError(customErr.errors)
            }else
                throw err

            throw errors
        }
    })
}

module.exports = {
    courseCreate,
    courseUpdate,
    courseDelete
}