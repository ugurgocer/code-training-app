const Mutation = require('./course.mutation')
const Query = require('./course.query')

module.exports = {
    Mutation,
    Query
}