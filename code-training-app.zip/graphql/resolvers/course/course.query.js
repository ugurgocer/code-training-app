const db = require('./../../../model/index')
const { regular } = require('./../../../utils/helpers/middleware')

const courseRead = async(_, { _id }, { req }, info) => {
    regular(req)
    try {
        const _course = await db.Course.findOne({ where: { _id } })
        return _course
    } catch (err) {
        throw err
    }
}

const courseList = async(_, { filter, sorting, paging }, { }, info) => {
    regular(req)
    try {
        const _courses = await db.Course.findAll()
        return _courses
    } catch (err) {
        
    }
}
module.exports = {
    courseRead,
    courseList
}