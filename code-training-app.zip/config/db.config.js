module.exports = {
    host: '127.0.0.1',
    port: '5432',
    dialect: 'postgres',
    database: 'schoolproject',
    username: 'postgres',
    password: 'D3vP@ssw0rd',
    logging: false
}