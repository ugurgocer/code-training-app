const tr = require('./tr')
const en = require('./en')

module.exports = {
    tr,
    en
}