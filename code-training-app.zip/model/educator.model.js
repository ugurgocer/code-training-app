const { Model, DataTypes } = require('sequelize')
const sequelize = require('../lib/db.constructor')

class Educator extends Model {}

Educator.init({
    name: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
            notEmpty: true
        }
    },
    description: {
        type: DataTypes.STRING,
        allowNull: true,
        validate: {
            len: ['0', '500']
        }
    },
    profilePicture: {
        type: DataTypes.STRING,
        allowNull: true,
        field: 'profile_picture',
    },
    registrationDate: {
        type: DataTypes.DATE,
        allowNull: false,
        field: 'registration_date',
        validate: {
            notEmpty: true
        }
    },
    lastLoginDate: {
        type: DataTypes.DATE,
        allowNull: false,
        field: 'last_login_date'
    }
}, {
    modelName: 'educators',
    sequelize
})

module.exports = Educator